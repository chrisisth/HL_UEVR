close all;
clear all;
clc;


####### Your input starts here #################################################

filename = "MyFilename";      # Filename of the .wav file to use as a source
                              # for the haptics. Name must not contain .wav,
                              # the script adds that automatically for you.
                              # Sound file must be in same directory as this
                              # script, and be mono instead of stereo
                                
FrequencyResolution = 1024;   # Inversely proportional to the time resolution
                              # of your end result! I usually set this somewhere
                              # between 256 for very short sounds to about 2048
                              # for long sounds

####### Your input ends here ###################################################






FullFileName = strjoin({filename ,"wav"}, '.');   # append .wav to the filename

[x, Fs] = audioread(FullFileName) # load the audiofile, store some vars from it

pkg load signal

# plot the spectrogram of the audio
figure
specgram(x,FrequencyResolution,Fs)
xlabel('Time [s]')
ylabel('Frequency [Hz]')
grid on
title('Spectrogram')


# Get all the info we need from the spectrogram
[S,f,t] = specgram(x,FrequencyResolution,Fs);

[Intensities, Indices] = max(abs(S));
Frequencies = f(Indices);
Intensities = Intensities/max(Intensities);   # Normalize the intensity values
                                              # so we avoid volume issues

                                              
# Acrobatics required to write the output files properly
FreqCurve = [t',Frequencies'];
IntensityCurve = [t',Intensities'];

filename_freqs = strjoin({filename ,"Frequencies_Curve"}, '_')
filename_freqs = strjoin({filename_freqs ,"csv"}, '.')
filename_Intensities = strjoin({filename ,"Intensities_Curve"}, '_')
filename_Intensities =strjoin({filename_Intensities ,"csv"}, '.')

HeaderMatrix = ['Time,Value'];

dlmwrite(filename_freqs, HeaderMatrix, "");
csvwrite (filename_freqs, FreqCurve, "-append");

dlmwrite(filename_Intensities, HeaderMatrix, "");
csvwrite (filename_Intensities,IntensityCurve, "-append");